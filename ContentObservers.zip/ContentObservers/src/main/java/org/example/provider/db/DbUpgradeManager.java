package org.example.provider.db;

public class DbUpgradeManager {
    public static final int DATABASE_VERSION = 1;
    public static final String VERSION_TABLE = "database_version";
}
